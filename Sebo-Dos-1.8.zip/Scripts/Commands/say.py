print("")
SayInput = str(input("Text: "))
print("")
print(SayInput)