import os

print("")

MainInput = str(input("Sebo-Dos:\cmd\ "))

os.system(MainInput)