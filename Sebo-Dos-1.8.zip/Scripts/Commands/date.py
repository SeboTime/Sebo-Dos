import imp


import datetime

print("")
print(datetime.date.today())