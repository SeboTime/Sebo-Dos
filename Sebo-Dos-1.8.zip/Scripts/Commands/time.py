import time

print("")
print(time.strftime("%H:%M:%S"))