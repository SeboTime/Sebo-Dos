import os

os.system("pip install --upgrade pip")
os.system("pip install PySimpleGUI")
os.system("pip install tqdm")